import Foundation

var v1 = "Esto es Swift"
let c1 = 4 

var cadena:String = String ()
cadena = "Hola Mundo " + v1

print ("El contenido es: \(cadena)")

print ("El valor de la constante es: \(c1)")